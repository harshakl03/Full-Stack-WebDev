import React,{ useState } from "react";
import "./styles.css";
import Item from "./list";

export default function App() {
  const [filteredItem , setFilteredItem] = useState(Item);

  function handleChange(event){
    const value = event.target.value;
    const searchItem = Item.filter((listItem)=> listItem.toLowerCase().includes(value.toLowerCase()) );
    value === "" ? setFilteredItem(Item) : setFilteredItem(searchItem);
  }

  return (
    <div className="App">
      <input type="text" onChange={handleChange} placeholder="Search..." />
      <div>{filteredItem.map((item)=> <div>{item}</div>)}</div>
    </div>
  );
}
